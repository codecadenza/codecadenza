/**
 * Enumeration of supported sort directions
 */
export enum SortDirectionEnum {
  NONE = 'NONE',
  ASC = 'ASC',
  DESC = 'DESC'
}

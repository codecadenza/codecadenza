/**
 * Domain object for changing password
 */
export class ChangePassword {
  oldPassword = '';
  newPassword = '';
  confirmedPassword = '';
}

/**
 * Domain object for selection items
 */
export class SelectionItem {
  label = '';
  value = '';
}

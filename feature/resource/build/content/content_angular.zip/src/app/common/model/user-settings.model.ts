/**
 * Domain object for global user settings
 */
export class UserSettings {
  dateFormat = '';
  dateTimeFormat = '';
  numberFormat = '';
  fontSize = 0;
}

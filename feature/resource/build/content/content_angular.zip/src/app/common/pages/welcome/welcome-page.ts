import { Component } from '@angular/core';

/**
 * Page for displaying general information about the generated application
 */
@Component({
  templateUrl: './welcome-page.html'
})
export class WelcomePage {}
